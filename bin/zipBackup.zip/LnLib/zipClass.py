#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# updated by ...: Loreto Notarantonio
# Version ......: 09-07-2020 17.09.41
#

import sys; sys.dont_write_bytecode=False
import os
import types  # per SimpleNamespace
import pdb
from   pathlib import Path # https://docs.python.org/3/library/pathlib.html
import zipfile # https://docs.python.org/3.6/library/zipfile.html
import pyzipper # https://pypi.org/project/pyzipper/
import shutil # https://docs.python.org/3/library/shutil.html
import datetime


class nullLogger():
    def dummy(self,  title, *args, **kwargs): pass
    critical=error=warning=info=debug1=debug2=debug3=dummy

# from LnLib.LnColor import LnColor; C=LnColor()
# https://gist.github.com/msunardi/6527ac4c3b08975d30f83cd8aa80e147
# https://pymotw.com/2/zipfile/

class LnZipClass:
    '''
    Open a ZIP file,
        where file can be:
           - a path to a file (a string),
           - a file-like object
           - a path-like object
    The mode parameter should be:
        'r' to read an existing file,
        'w' to truncate and write a new file,
        'a' to append to an existing file, or
        'x' to exclusively create and write a new file.
    If mode is 'x' and file refers to an existing file, a FileExistsError will be raised.
    If mode is 'a' and file refers to an existing ZIP file, then additional files are added to it.
    '''

    def __init__(self, filename, mode, secret_password=None, compression=zipfile.ZIP_STORED, logger=None):

        self.logger=logger if logger else nullLogger()
        self._zf=None

        try:
            import zlib
            self._compression = zipfile.ZIP_DEFLATED # compression_type=8
        except:
            self._compression = zipfile.ZIP_STORED # compression_type=0

        self._mode=mode
        self.open(filename, mode)

    def open(self, filename, mode):
        self.close()
        # filename=Path(filename)
        if filename:
            if secret_password:
                self._zf=pyzipper.AESZipFile(filename, mode=mode,
                             compression=pyzipper.ZIP_LZMA)
                self._zf.setpassword(secret_password)
                self._zf.setencryption(pyzipper.WZ_AES, nbits=256)
            else:
                self._zf=zipfile.ZipFile(filename, mode=mode, compression=self._compression)


    def is_zipfile(self, filename):
        return zipfile.is_zipfile(filename)

    def print_info(self):
        for info in self._zf.infolist():
            print(info.filename)
            print('\tcompress_type:\t', info.compress_type)
            print('\tModified:\t', datetime.datetime(*info.date_time))
            print('\tSystem:\t\t', info.create_system, '(0 = Windows, 3 = Unix)')
            print('\tZIP version:\t', info.create_version)
            print('\tCompressed:\t', info.compress_size, 'bytes')
            print('\tUncompressed:\t', info.file_size, 'bytes')
            print('\tComment:\t', info.comment)
            print()
            # print(info)

        print()
        for name in self._zf.namelist():
            print('     ', name)
        print()


    def close(self):
        if self._zf:
            self._zf.close()

    '''
        zip_ns=types.SimpleNamespace()
        zip_ns.root_dir='/mnt/k/Filu/LnDisk/Loreto'
        zip_ns.include=['**/*']
        zip_ns.exclude=['2015', 'sync.ffs_db']
        zip_ns.compression_type=None

        '*' solo dirs
        '*/*' solo files
        '**/*' tutto
    '''
    # def oneFolderOneZip(self, root_dir, include=['**/*'], exclude=[], compression_type=None):
    #     req_compression=compression_type if compression_type else self._compression
    #     root_dir = Path(root_dir)
    #     # sub_directory di livello 1
    #     dirs = [e for e in root_dir.iterdir() if e.is_dir()]
    #     files = [e for e in root_dir.iterdir() if e.is_file()]
    #     for _dir in sorted(dirs):
    #         dir_name=_dir.stem
    #         if dir_name.lower() in ['curriculuum']: return
    #         self.addFolder(root_dir, dir_name, include=include, exclude=exclude, req_compression=req_compression)

    def addFolder(self, root_dir, dir_name, include=['**/*'], exclude=[], compression=None, fVERBOSE=0):
        compression=compression if compression else self._compression
        my_dir=Path(root_dir / dir_name)
        print(my_dir)
        my_list=[]
        for pattern in include:
            _list = list(my_dir.glob(pattern))
            my_list.extend(_list)

        # remove duplicates ... anche list( dict.fromkeys(_val)
        # my_list=list( dict.fromkeys(my_list) )
        my_list=list(set(my_list))
        if exclude:
            for path in my_list[:]:
                for ecl_pattern in exclude:
                    if ecl_pattern in str(path): # anche path.stem
                        my_list.remove(path)


        for file in my_list:
            archive_name=file.relative_to(root_dir)
            if fVERBOSE>0: print (archive_name)
            this_compression=zipfile.ZIP_STORED if file.suffix.lower() in ['.jpg', '.zip', '.xdocx'] else compression
            self._zf.write(file, arcname=archive_name, compress_type=this_compression)
            if fVERBOSE>1:
                if file.is_file() and file.stat().st_size:
                    info=self._zf.getinfo(str(archive_name))
                    percent=1-(info.compress_size/info.file_size)
                    print(f'                - comp_type: {info.compress_type}')
                    print(f'                - comp_rate: {abs(percent):2.0%}')
            # print(info)
            # print('\tcompress_type:\t', info.compress_type)
            # print('\tModified:\t', datetime.datetime(*info.date_time))
            # print('\tSystem:\t\t', info.create_system, '(0 = Windows, 3 = Unix)')
            # print('\tZIP version:\t', info.create_version)
            # print('\tCompressed:\t', info.compress_size, 'bytes')
            # print('\tUncompressed:\t', info.file_size, 'bytes')
            # print('\tComment:\t', info.comment)
            # print()

        return

def oneFolderOneZip(root_dir, target_dir, sub_dirs=[], include=['**/*'], exclude=[], secret_password=None):
    if not sub_dirs:
        sub_dirs = [e.stem for e in root_dir.iterdir() if e.is_dir()]
        files = [e for e in root_dir.iterdir() if e.is_file()]
    else:
        files=[]

    # pdb.set_trace()
    for dir_name in sorted(sub_dirs):
        _target_dir=Path(f'{target_dir}/{root_dir.stem}')
        _target_dir.mkdir(parents=False, exist_ok=True)

        zip_name=Path(f'{_target_dir}/{dir_name}.zip')
        myZip=LnZipClass(zip_name, mode='w', secret_password=secret_password)
        myZip.addFolder(root_dir, dir_name, include=include, exclude=exclude)




if __name__ == '__main__':

    root_dir='/mnt/k/Filu/LnDisk/Loreto'
    secret_password=b'ciao'
    secret_password=None
    root_dir=Path('/mnt/k/Filu/LnDisk/Lesla')
    target_dir='/mnt/k/temp'

    sub_dirs = ['Loreto', 'Lesla']
    sub_dirs = []
    oneFolderOneZip(root_dir, target_dir, sub_dirs=sub_dirs, include=['**/*'], exclude=[])






    # zipFile     = '/mnt/k/temp/test_001.zip'
    # myZip = LnZipClass(zipFile, mode='w', secret_password=secret_password)
    # zip_ns=types.SimpleNamespace()
    # zip_ns.root_dir='/mnt/k/Filu/LnDisk/Loreto'
    # zip_ns.include=['**/*']
    # zip_ns.exclude=['2015', 'sync.ffs_db']
    # zip_ns.compression_type=None

    # myZip.oneFolderOneZip(root_dir=source_dir, include=['**/*'], exclude=['2015', 'sync.ffs_db'])
    # myZip.oneFolderOneZip(zip_ns)
    # myZip.addFolder(source_dir, include=['**/*'], exclude=['2015', 'sync.ffs_db'])
    # myZip.print_info()
    # myZip.close()


    # crypting
    # cryptFile='/mnt/k/temp/test_001_crypt.zip'
    # myZip = LnZipClass(cryptFile, mode='w', secret_password=b'ciao')
    # myZip.addFolder(source_dir, include=['**/*'], exclude=['2015', 'sync.ffs_db'])
    # myZip.addFolder(source_dir, include=['*', '*/*', '**/*'], exclude=[])
    # myZip.addFolder('/mnt/k/Filu/LnDisk/Loreto', exclude=['sync.ffs_db'])
    # myZip.addFolder('/mnt/k/Filu/LnDisk/Lesla', exclude=['sync.ffs_db'])
    # myZip.addFolder('l:/Loreto/ProjectsAppl/_Python/LnFunctions_OldStyle', include=['initLog.py'])
    # myZip.print_info()
    # myZip.close()

